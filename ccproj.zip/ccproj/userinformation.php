<?php
$server = db-2.cprd40v0lfdc.us-east-1.rds.amazonaws.com; 
$username = "admin";
$password = 12345678;
$database = userinfo;

$connection = mysqli_connect($server,$username,$password,$database);

mysqli_select_db($connection,"userinfo");

$user = $_POST['user'];
$email = $_POST['email'];
$message = $_POST['message'];

$query = "INSERT INTO `userdata`(`user`,`email`,`message`) VALUES ('$user','$email','$message') ";

mysqli_query($connection,$query);

echo "MESSAGE IS SENT";

?>
